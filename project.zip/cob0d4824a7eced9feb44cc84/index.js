fetch("http://www.omdbapi.com/?i=tt3896198&apikey=5f71559")
    .then(res => res.json())
    .then(data => console.log(data))
